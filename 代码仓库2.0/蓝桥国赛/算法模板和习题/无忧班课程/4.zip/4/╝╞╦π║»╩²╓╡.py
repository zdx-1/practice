import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

def s(x):
    print(f'x={x}')
    if x == 0:
        print('s(0)=1')
        return 1
    if x & 1:
        t = s(x-1) + 1
        print(f's({x})={t}')
        return t
    t = s(x//2)
    print(f's({x})={t}')
    return t

t = 1
ans = []
for _ in range(t):
    x = ii()
    print(s(x))