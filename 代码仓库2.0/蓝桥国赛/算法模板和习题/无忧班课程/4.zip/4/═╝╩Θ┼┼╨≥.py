class Book:
   def __init__(self, id, weight):
       self.id = id
       self.weight = weight

def compare(a, b):
   if a.weight == b.weight:
       return a.id < b.id  # 当权重相同，按ID排序
   return a.weight < b.weight

def shellSort(books):
   N = len(books)
   gap = N // 2
   while gap > 0:
       for i in range(gap, N):
           temp = books[i]
           j = i
           while j >= gap and compare(temp, books[j - gap]):
               books[j] = books[j - gap]
               j -= gap
           books[j] = temp
       gap //= 2
N = int(input())
books = [Book(*map(int, input().split())) for _ in range(N)]
shellSort(books)
for book in books:
   print(book.id)