import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = 1
ans = []
for _ in range(t):
    t = ii()
    a = [-1 for _ in range(1000001)]
    cur = 1
    step = 0
    while cur <= 1000000:
        a[cur] = step
        # 计算当前石头的各位数字之和
        res = 0
        for i in str(cur):
            res += ord(i) - ord('0')
        # 走到下一块石头上
        cur = cur + res
        step += 1
    for _ in range(t):
        n = ii()
        print(a[n])