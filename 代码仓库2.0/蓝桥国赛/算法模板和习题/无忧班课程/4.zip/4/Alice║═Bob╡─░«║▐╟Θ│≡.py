import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = 1
ans = []
for _ in range(t):
    n, k = il()
    a = il()
    sum1 = 0
    # 奇数堆的数量
    for x in a:
        sum1 += x & 1
    if sum1 & 1:
        print('Alice')
    else:
        print('Bob')