n = int(input())
m = int(input())
increments = list(map(int, input().split()))
arr = [int(input()) for _ in range(n)]
compare_count = 0
swap_count = 0
for h in increments:
   for i in range(h, n):
       temp = arr[i]
       j = i
       while j >= h:
            compare_count += 1
            if arr[j-h] > temp:
               arr[j] = arr[j - h]
               j -= h
               swap_count += 1
            else:
               break
       arr[j] = temp
print(compare_count, swap_count)