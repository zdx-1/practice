import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = ii()
ans = []
for _ in range(t):
    n = ii()
    a = il()
    sum1, z = sum(a), 0
    for i in range(0,n):
        if not a[i]:
            z += 1
    sum1 += z
    if sum1 == 0: 
        print(z+1)
    else:
        print(z)
