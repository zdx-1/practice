import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = 1
ans = []
for _ in range(t):
    n, q = il()
    a = il()
    d = [0 for _ in range(n+1)]
    d[0] = a[0]
    for i in range(1,n):
        d[i] = a[i] - a[i-1]
    for _ in range(q):
        l, r, c = il()
        l -= 1
        r -= 1
        d[l] += c
        d[r+1] -= c
    a[0] = d[0]
    ans.append(a[0])
    for i in range(1,n):
        a[i] = a[i-1] + d[i]
        ans.append(a[i])
    print(' '.join(map(str,ans)))