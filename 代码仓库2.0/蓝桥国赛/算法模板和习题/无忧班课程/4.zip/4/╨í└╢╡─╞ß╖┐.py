import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = ii()
ans = []
for _ in range(t):
    n, k = il()
    a = il()
    res = float('inf')
    for i in range(1, 61):
        cnt = 0
        b = a.copy()
        for j in range(n):
            if b[j] != i:
                for h in range(j, min(j+k, n)):
                    b[h] = i
                j = j + k - 1
                cnt += 1
        res = min(res, cnt)
    print(res)