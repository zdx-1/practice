import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = 1
ans = []
for _ in range(t):
    n = ii()
    m = 1000100
    a = [0 for _ in range(m)]
    for _ in range(n):
        w, p = il()
        # 把石头加到对应的位置上
        a[p] += w
    pre = [0 for _ in range(m)]
    suf = [0 for _ in range(m)]
    sum1 = 0
    for i in range(1,m):
        pre[i] = pre[i-1] + sum1
        sum1 += a[i]
    sum1 = 0
    for i in range(m-2,0,-1):
        suf[i] = suf[i+1] + sum1
        sum1 += a[i]
    ans = float('inf')
    for i in range(1,m):
        ans = min(ans,pre[i]+suf[i])
    print(ans)