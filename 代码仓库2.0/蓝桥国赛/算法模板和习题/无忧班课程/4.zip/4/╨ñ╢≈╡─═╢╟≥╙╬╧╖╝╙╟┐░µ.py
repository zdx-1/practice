import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = 1
ans = []
for _ in range(t):
    n, m, q = il()
    g = []
    for i in range(n):
        g.append(il())
    d = [[0 for _ in range(m+1)] for _ in range(n+1)]
    for i in range(n):
        for j in range(m):
            d[i][j] = g[i][j]
            if i:
                d[i][j] -= g[i-1][j]
            if j:
                d[i][j] -= g[i][j-1]
            if i and j:
                d[i][j] += g[i-1][j-1]
    for i in range(q):
        x1, y1, x2, y2, c = il()
        x1 -= 1
        y1 -= 1
        x2 -= 1
        y2 -= 1
        d[x1][y1] += c
        d[x2+1][y1] -= c
        d[x1][y2+1] -= c
        d[x2+1][y2+1] += c
    for i in range(n):
        res = []
        for j in range(m):
            g[i][j] = d[i][j]
            if i:
                g[i][j] += g[i-1][j]
            if j:
                g[i][j] += g[i][j-1]
            if i and j:
                g[i][j] -= g[i-1][j-1]
            res.append(g[i][j])
        print(' '.join(map(str,res)))
