N = 100010
n = 0
q = [(0, 0)] * N
pre = [0] * N
nex = [0] * N
n = int(input().strip())
for i in range(1, n + 1):
   y, x = map(int, input().strip().split())
   q[i] = (x, y)
q[1:n + 2] = sorted(q[1:n + 1])
s = 0
for i in range(1, n + 1):
   pre[i] = pre[i - 1] + s * (q[i][0] - q[i - 1][0])
   s += q[i][1]
s = 0
for i in range(n, 0, -1):
   nex[i] = nex[i + 1] + s * (q[i + 1][0] - q[i][0]) if i != n else 0
   s += q[i][1]
res = min(pre[i] + nex[i] for i in range(1, n + 1))
print(res)