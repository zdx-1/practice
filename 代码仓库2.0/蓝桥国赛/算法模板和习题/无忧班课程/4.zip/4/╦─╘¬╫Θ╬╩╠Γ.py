def FoursNumberFind(nums):
   st = []
   n = len(nums)
   k = float('-inf')
   INF = float('inf')
   # min_r[i] = min(nums[r]), i < r < n。
   # 表示第i个数（不包括第i个数）右边的最⼩值
   min_r = [INF] * n
   # ⽤前缀和⽅法求 min_r 数组
   for i in range(n - 2, -1, -1):
       min_r[i] = min(min_r[i + 1], nums[i + 1])
   # ⽤单调栈求下标位 nums[c] < nums[a] < nums[b] 的情况
   for i in range(n):
       # 下标 i 即为 c ，k 即为 nums[a]
       if nums[i] < k:  # 如果存在  nums[c] < nums[a] < nums[b] 的情况
           # 判断 c 的右边是否 有⽐ nums[c] ⼩的数， 有则表示存在下标 d ，返回true
           if nums[i] > min_r[i]:
               return True
       # 如果栈不为空并且栈顶元素⼩于当前访问的元素
       while st and st[-1] < nums[i]:
           # 需要找满⾜⼩于nums[b]的最⼩ k 值
           k = max(k, st[-1])
           st.pop()
       # 压⼊栈顶，即为更新 nums[b]
       st.append(nums[i])
   return False
n = int(input())
nums = list(map(int, input().split()))
if FoursNumberFind(nums):
   print("YES")
else:
   print("NO")