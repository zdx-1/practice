import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = 1
ans = []
for _ in range(t):
    n = ii()
    a = il()
    a.sort(reverse=True)
    for i in range(n-2):
        for j in range(i+1,n-1):
            for k in range(j+1,n):
                ans.append(a[i]+a[j]+a[k])
    # 将list转为set后，会对list内的元素进行去重并排序
    ans = list(set(ans))
    print(ans[-3])
    