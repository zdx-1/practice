import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = ii()
ans = []
for _ in range(t):
    n, k = il()
    a = il()
    a.sort()
    s = [0 for _ in range(n)]
    s[0] = a[0]
    for i in range(1,n):
        s[i] = s[i - 1] + a[i]
    ans = s[n-1-k]
    for i in range(1,k+1):
        ans = max(ans,s[n-1-(k-i)]-s[2*i-1])
    print(ans)
    