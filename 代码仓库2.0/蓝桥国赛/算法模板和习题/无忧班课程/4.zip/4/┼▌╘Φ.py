import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = 1
ans = []
N = 200010
for _ in range(t):
    n, w = il()
    d = [0 for i in range(N)]
    d[0] += w
    for _ in range(n):
        s, t, p = il()
        d[s] -= p
        d[t] += p
    f = 1
    for i in range(1,N):
        d[i] += d[i-1]
    for i in range(N):
        if d[i] < 0:
            f = 0
            break
    if f:
        print("Yes")
    else:
        print("No")