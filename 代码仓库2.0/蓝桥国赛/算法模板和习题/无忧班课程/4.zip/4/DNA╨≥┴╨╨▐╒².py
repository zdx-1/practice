import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = 1
ans = []
for _ in range(t):
    mp = {
       'A': 0,
       'C': 1,
       'G': 2,
       'T': 3
    }
    n = ii()
    a = read()
    b = list(read())
    cnt = 0
    for i in range(n):
        if mp[a[i]] + mp[b[i]] != 3:
            # 此时对应位置不匹配
            for j in range(i+1, n):
                # 如果能够交换b中两个位置，完成匹配，就交换
                if mp[a[i]] + mp[b[j]] == 3 and mp[a[j]] + mp[b[i]] == 3:
                    b[i], b[j] = b[j], b[i]
                    break
            cnt += 1
    print(cnt)