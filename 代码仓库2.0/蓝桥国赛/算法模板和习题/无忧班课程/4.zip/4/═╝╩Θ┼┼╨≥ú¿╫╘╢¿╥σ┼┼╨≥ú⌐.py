import sys

def read():
    return sys.stdin.readline().strip()

def ii():
    return int(read())

def il():
    return list(map(int,read().split()))

t = 1
ans = []
for _ in range(t):
    n = ii()
    d = []
    for _ in range(n):
        Id, w = il()
        d.append({"Id":Id,"w":w})
    d = sorted(d,key=lambda x:(x['w'],x['Id']))
    for item in d:
        print(item['Id'])